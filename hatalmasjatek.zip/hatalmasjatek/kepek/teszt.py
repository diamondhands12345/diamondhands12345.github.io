
import pygame
import sys
import time as ido
from datetime import datetime


pygame.init()
clock= pygame.time.Clock()
screen = pygame.display.set_mode(((1366),(768)))
pygame.display.set_caption("The Clue")


#PICTURES
magni=[pygame.image.load("magni2.png"),pygame.image.load("magni2.2.png"),pygame.image.load("magni2.3.png"),pygame.image.load("magni2.4.png"),pygame.image.load("magni2.5.png"),pygame.image.load("magni2.6.png"),pygame.image.load("magni2.7.png"),pygame.image.load("magni2.8.png"),pygame.image.load("magni2.9.png")]
h1=pygame.image.load("menu.png")
footright=pygame.image.load("footprintright.png")
footleft=pygame.image.load("footprintleft.png")
street1=pygame.image.load("hatter1.png")
transi = [pygame.image.load("transition1.png"), pygame.image.load("transition2.png"), pygame.image.load("transition3.png"), pygame.image.load("transition4.png"), pygame.image.load("transition5.png"), pygame.image.load("transition6.png"), pygame.image.load("transition7.png"), pygame.image.load("transition8.png")]
notebook = pygame.image.load("notebook.png")
settingfade=pygame.image.load("settingshadow.png")
settingssymbol=[pygame.image.load("settings2.png"),pygame.image.load("settings1.png")]
arrow=[pygame.image.load("arrow1.png"), pygame.image.load("arrow2.png")]
insettings_face=[pygame.image.load("insettings1.png"),pygame.image.load("insettings2.png"),pygame.image.load("insettings3.png")]
moving_right = [pygame.image.load("figure1_11.png"), pygame.image.load("figure1_13.png"), pygame.image.load("figure1_14.png"), ]
moving_left = [pygame.image.load("figure1_11_left.png"),  pygame.image.load("figure1_13_left.png"), pygame.image.load("figure1_14_left.png"), ]
speaker_face=[pygame.image.load("speaker1.png"), pygame.image.load("speaker2.png"), pygame.image.load("speaker3.png"), pygame.image.load("speaker4.png")]

#VARIABLES
x=946
y=201
kulx,kuly=0,0
magniface=0
ftrx,ftry,ftlx,ftly=1366,0,-1366,0
RED = (255, 0, 0)
helperx,helpery=1366,0
font = pygame.font.SysFont(None, 24)
transix = 0
COLOR_ACTIVE = pygame.Color(223, 48, 48)
COLOR_INACTIVE = pygame.Color('gray15')
FONT = pygame.font.Font(None, 32)
phase1 = True
phase2 = False
notepad = False
settings_serial=0
arrow_serial=0
insettings_serial=0
bentvan=False
adjuster_x= 543
adjuster_y= 406
adjuster_x_serial=0
difference_x, difference_y=0,0
pullingmouse=False
settingsactive=False
insettings_active=False
volumesettings, skinsettings, infosettings, in_wrench=False, False, False, False
speaker_serail=0
speaker_x, speaker_y=325,400
jobbra, balra = False, False
moving_left_dx = 0
moving_right_dx = 0
moving_coords = [75, 545]
jobbranez, balranez = True, False
fel, le = False, False
#INPUTBOX
class InputBox:

    def __init__(self, x, y, w, h, text=''):
        self.rect = pygame.Rect(x, y, w, h)
        self.color = COLOR_INACTIVE
        self.text = text
        self.txt_surface = FONT.render(text, True, self.color)
        self.active = False

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            if self.rect.collidepoint(event.pos):
                self.active = not self.active
            else:
                self.active = False
            self.color = COLOR_ACTIVE if self.active else COLOR_INACTIVE
        if event.type == pygame.KEYDOWN:
            if self.active:
                if event.key == pygame.K_BACKSPACE:
                    self.text = self.text[:-1]
                else:
                    self.text += event.unicode
                self.txt_surface = FONT.render(self.text, True, self.color)

    def update(self):
        width = max(200, self.txt_surface.get_width()+10)
        self.rect.w = width

    def draw(self, screen):
        screen.blit(self.txt_surface, (self.rect.x+5, self.rect.y+5))
        pygame.draw.rect(screen, self.color, self.rect, 2)
input_box1 = InputBox(347,118,140,32)
input_box2 = InputBox(418,192,140,32)
input_box3 = InputBox(357,267,140,32)
input_box4 = InputBox(251,396,140,32)
input_box5 = InputBox(825,121,140,32)
input_box6 = InputBox(898,192,140,32)
input_box7 = InputBox(841,266,140,32)
input_box8 = InputBox(730,396,140,32)
input_boxes = [input_box1, input_box2, input_box3, input_box4, input_box5, input_box6, input_box7, input_box8]



#DEFS
def nagyitomozgatas():
    global x, y, kulx, kuly
    if pygame.mouse.get_pressed()[0] == 1 and x+101 < pygame.mouse.get_pos()[0] < x+155 and y+286 < pygame.mouse.get_pos()[1] < y+517:
        egerx,egery=pygame.mouse.get_pos()
        if event.type==pygame.MOUSEBUTTONDOWN:
            kulx, kuly = (egerx - x), (egery - y)        
        x, y = (egerx - kulx), (egery - kuly)  

def toltes():
    global x, y, magniface
    mehet=True
    if mehet:
        if 210<y<317 and 490<x<596 and magniface<8:
            magniface+=0.04
                          
        elif magniface==8:
            mehet=False
           
        elif magniface<8:
            magniface=0

def footprints():
    global magniface, ftrx,ftry, ftlx,ftly, helperx

    if magniface>=8 and ftrx>10:
        screen.blit(footright,(ftrx,ftry))
        screen.blit(footleft,(ftlx,ftly))
        helper=pygame.Rect(helperx,helpery,683,768)
        pygame.draw.rect(screen,(0,0,0),helper)
        ftrx-=10
        helperx=ftrx+683
        ftlx+=10

def transition():
    global transix, phase1, phase2
    if ftrx<=10 and transix <= 7:
        screen.blit(street1, (0, 0))
        screen.blit(transi[transix], (0, 0))
        transix += 1
        ido.sleep(0.03)
    elif phase1 and transix > 7:
        ido.sleep(0.03)
        phase1 = False
        phase2 = True

def noting():
    global notepad
    if pygame.key.get_pressed()[pygame.K_n] and not notepad:
        notepad = True
    if notepad:
        screen.blit(notebook,(183,53))
        for box in input_boxes:
            box.draw(screen)
        if 226 < pygame.mouse.get_pos()[0] < 291 and 635 < pygame.mouse.get_pos()[1] < 676 and pygame.mouse.get_pressed()[0]==1:
            notepad = False

def ifsettingsactive():
    global settingsactive, insettings_active
    if settingsactive:
        screen.blit(settingfade,(0,0))
        screen.blit(settingssymbol[round(settings_serial)],(566,272))
        screen.blit(arrow[arrow_serial],(15,15))
        screen.blit(clock1, (1150, 690))
        screen.blit(clock2, (620, 650))
        if insettings_active:
            screen.blit(insettings_face[insettings_serial],(200,113))
            if volumesettings:
                adjuster=pygame.Rect(adjuster_x,adjuster_y,25,81)
                pygame.draw.rect(screen,(0,0,0),adjuster,0)
                screen.blit(speaker_face[speaker_serail],(speaker_x, speaker_y))

def egerxy():
    global moving_coords
    egerx, egery = pygame.mouse.get_pos()
    pozi = font.render(str(egerx)+" "+str(egery)+" "+str(moving_coords[0])+" "+str(moving_coords[1]), True, RED)
    if pygame.key.get_pressed()[pygame.K_q]:
        screen.blit(pozi, (20, 100))

def mozgas():
    global jobbra, balra, moving_right_dx, moving_left_dx, moving_coords, jobbranez, balranez, fel, le
    if pygame.key.get_pressed()[pygame.K_RIGHT] and moving_coords[0] < 1271:
        jobbra = True
        jobbranez = True
        balranez = False
    if pygame.key.get_pressed()[pygame.K_LEFT] and moving_coords[0] > -25:
        balra = True
        jobbranez = False
        balranez = True
    if pygame.key.get_pressed()[pygame.K_UP] and moving_coords[1] > 329:
        fel = True
        jobbra, balra = False, False
        moving_coords[1] -= 2
    if pygame.key.get_pressed()[pygame.K_DOWN] and moving_coords[1] < 567:
        le = True
        jobbra, balra = False, False
        moving_coords[1] += 2
    if jobbra and not balra:
        moving_coords[0] += 2
        screen.blit(moving_right[round(moving_right_dx) % 3], moving_coords)
        moving_right_dx += 0.1
    if balra and not jobbra:
        moving_coords[0] -= 2
        screen.blit(moving_left[round(moving_left_dx) % 3], moving_coords)
        moving_left_dx += 0.1     
    if not jobbra and not balra or balra and jobbra or fel or le:
        moving_left_dx = 0
        moving_right_dx = 0
        if jobbranez:
            screen.blit(moving_right[2], moving_coords)
        if balranez:
            screen.blit(moving_left[2], moving_coords)
    jobbra, balra, fel, le = False, False, False, False
#SETTINGS
def settings():
        global settingsactive, bentvan, settings_serial, arrow_serial, time, date, clock1, clock2, insettings_serial, volumesettings, skinsettings, infosettings, in_wrench, insettings_active, difference_y, difference_x, adjuster_x, adjuster_y, mouse_y, mouse_x,pullingmouse,speaker_serail
        pressed=pygame.key.get_pressed()
        if event.type==pygame.MOUSEBUTTONUP:
                    pullingmouse=False
        if pressed[pygame.K_ESCAPE]:
            if settingsactive==False:
                settingsactive= not settingsactive
        if bentvan and pygame.mouse.get_pressed()[0]==1:
            settingsactive=False
            bentvan=False
        if settingsactive:
            if pygame.mouse.get_pos()[0]<579 or 779<pygame.mouse.get_pos()[0]:
                settings_serial=0
                in_wrench=False
            
            if pygame.mouse.get_pos()[1]<278 or 492<pygame.mouse.get_pos()[1]:
                settings_serial=0
                in_wrench=False

            if 579 < pygame.mouse.get_pos()[0]< 779 and 278 < pygame.mouse.get_pos()[1] < 492 and not insettings_active:
                settings_serial=1
                in_wrench=True
                
            
        if settingsactive:
            if pygame.mouse.get_pos()[0]<40 or 120<pygame.mouse.get_pos()[0] and not insettings_active:
                arrow_serial=0
                bentvan=False
            if pygame.mouse.get_pos()[1]<50 or 110<pygame.mouse.get_pos()[1] and not insettings_active:
                arrow_serial=0
                bentvan=False
            if 40 < pygame.mouse.get_pos()[0]< 110 and 50 < pygame.mouse.get_pos()[1] < 110 and not insettings_active:
                arrow_serial=1
                bentvan=True

        date= datetime.now().date()
        time= datetime.now().time()
        fontclock1 = pygame.font.SysFont("Trebuchet MS", 40)
        fontclock2 = pygame.font.SysFont("Trebuchet MS", 50)
        clock1 = fontclock1.render((str(date.year)+"."+str(date.month)+"."+str(date.day)+"."), True, (255,255, 255))
        clock2 = fontclock2.render((str(time.hour)+":"+str(time.minute)), True,(0,0,0) )

        if in_wrench and pygame.mouse.get_pressed()[0]==1:
            insettings_active=True
            insettings_serial=0
            in_wrench=False

        if pygame.mouse.get_pressed()[0]==1 and insettings_active:
            
            if 208 < pygame.mouse.get_pos()[0]< 509 and 119 < pygame.mouse.get_pos()[1] < 209 and not pullingmouse:
                insettings_serial=0
                infosettings=True
                skinsettings=False
                volumesettings=False
            if 522 < pygame.mouse.get_pos()[0]< 838 and 119 < pygame.mouse.get_pos()[1] < 209 and not pullingmouse:
                insettings_serial=1
                skinsettings=True
                infosettings=False
                volumesettings=False
            if 852 < pygame.mouse.get_pos()[0]< 1155 and 119 < pygame.mouse.get_pos()[1] < 209:
                insettings_serial=2
                volumesettings=True
                infosettings=False
                skinsettings=False
            if True:
                if (pygame.mouse.get_pos()[0]<195 or 1169<pygame.mouse.get_pos()[0]) and not pullingmouse:
                    insettings_active=False
                    volumesettings=False
                    infosettings=False
                    skinsettings=False
                    
                if (pygame.mouse.get_pos()[1]<107 or 659<pygame.mouse.get_pos()[1]) and not pullingmouse:
                    insettings_active=False
                    volumesettings=False
                    infosettings=False
                    skinsettings=False
            
            if volumesettings:
                mouse_x,mouse_y=pygame.mouse.get_pos()
                
                if pygame.mouse.get_pressed()[0] == 1 and adjuster_x<mouse_x<(adjuster_x+25) and 406<mouse_y<487:
                    
                    pullingmouse=True
                if pullingmouse:
                    mouse_x,mouse_y=pygame.mouse.get_pos()
                    if event.type==pygame.MOUSEBUTTONDOWN:
                        difference_x,difference_y=(mouse_x-adjuster_x),(mouse_y-adjuster_y)
                    adjuster_x=(mouse_x-difference_x)
                    if adjuster_x<544:
                        adjuster_x=544
                    if adjuster_x>795:
                        adjuster_x=795

                if adjuster_x<545:
                    speaker_serail=3
                elif 545<=adjuster_x<640:
                    speaker_serail=2
                elif 640<=adjuster_x<730:
                    speaker_serail=1
                elif 730<=adjuster_x:
                    speaker_serail=0


#UPDATES
def update():
    screen.blit(h1,(0,0))
    screen.blit(magni[round(magniface)],(x,y))  
    
    nagyitomozgatas()
    toltes()
    footprints()
    transition()
    egerxy()  
    settings()
    ifsettingsactive()

    
    pygame.display.update()

def update2():
    screen.blit(street1, (0, 0))  
    for box in input_boxes:
            box.update()    
    
    noting()
    egerxy()
    settings()
    ifsettingsactive()
    mozgas()
    
    
    pygame.display.update()


#GAME
while True:

    for event in pygame.event.get(): 
        if event.type==pygame.QUIT:
            pygame.quit()
            sys.exit()
        for box in input_boxes:
                box.handle_event(event)
            

        
    if phase1:
        update()
    if phase2:
        update2()
        
    clock.tick(60)


            ##############################
            ##           <<>>           ##
            ##           <<>>           ##
            ##           <<>>           ##
            ##    <<<<<<<<<>>>>>>>>>    ##
            ##    <<<<<<<<<>>>>>>>>>    ##
            ##           <<>>           ##
            ##           <<>>           ##
            ##           <<>>           ##
            ##           <<>>           ##
            ##           <<>>           ##
            ##           <<>>           ##
            ##############################



            ##############################
            ##       <<<<<<>>>>>>       ##
            ##     <<<          >>>     ##
            ##    <<              >>    ##
            ##     <              >>    ##
            ##                  >>>     ##
            ##                >>>       ##
            ##             >>>>         ##
            ##            <>            ##
            ##                          ##
            ##           <<>>           ##
            ##           <<>>           ##
            ##############################
