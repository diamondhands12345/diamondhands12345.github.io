import pygame
import sys
import time
pygame.init()

screen = pygame.display.set_mode(((1366),(768)))


while True:
    for event in pygame.event.get(): 
        if event.type==pygame.QUIT:
            pygame.quit()
            sys.exit()
    if event.type==pygame.MOUSEBUTTONDOWN:
        print("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA")
    if event.type==pygame.MOUSEBUTTONUP:
        print("EEEEEEEEEEEEEEEEEEEEEEEEE")
    print("0000000")
    pygame.display.update()