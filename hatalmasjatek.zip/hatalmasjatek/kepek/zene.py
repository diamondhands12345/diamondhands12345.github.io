import sys
import pygame
import time as ido

pygame.init()
pygame.mixer.init()
clock= pygame.time.Clock()
screen = pygame.display.set_mode(((1366),(768)))
pygame.display.set_caption("The Clue")










pygame.mixer.music.load("booting.wav")
pygame.mixer.music.play()

a_1=0
counter=0
a_2=0
counter_2=0
normal2=True
dupla2=False
waitforit=0
mailincoming=0
man_intro_serial=0
beep_done=False
mail_opening=False
mail_serial=12
helppper=True
timer=0
black_serial=6
dawns=True


redrect2_serial=0
cursor_x, cursor_y= 1155, 560
mail_activeopening=False

blackout=pygame.image.load("blackout.png")
man_intro=[pygame.image.load("face1.png"), pygame.image.load("face2.png")]

white=pygame.image.load("feher_1.png")
colors_forsencd= [pygame.image.load("lila_1.png"),pygame.image.load("zold_1.png"),pygame.image.load("kek_1.png"),pygame.image.load("feher_1.png")]
colors_serial=3
pcmail=[pygame.image.load("pcmail.png"), pygame.image.load("mail.png"),pygame.image.load("pcmail_2.png")]

black_forsencd=[pygame.image.load("fekete_1.png"),pygame.image.load("fekete_2.png"),pygame.image.load("fekete_3.png"),pygame.image.load("fekete_4.png"),pygame.image.load("fekete_5.png"),pygame.image.load("fekete_6.png"),pygame.image.load("fekete_7.png")]

cursor=pygame.image.load("cursor.png")

mail_face=[pygame.image.load("mail2.png"),pygame.image.load("mail3.png"),pygame.image.load("mail4.png"),pygame.image.load("mail5.png"),pygame.image.load("mail7.png"),pygame.image.load("mail8.png"),pygame.image.load("mail9.png"),pygame.image.load("mail10.png"),pygame.image.load("mail11.png"),pygame.image.load("mail12.png"),pygame.image.load("mail13.png"),pygame.image.load("mail14.png"),pygame.image.load("mail15.png")]

power=[pygame.image.load("poweroff.png"), pygame.image.load("poweroff2.png")]
samsung=pygame.image.load("samsung.png")
redrect=[pygame.image.load("redrect_4.png"),pygame.image.load("redrect_3.png"),pygame.image.load("redrect_2.png"),pygame.image.load("redrect_1.png")]
redrect_serial=0

redrect2=[pygame.image.load("redrect2_4.png"),pygame.image.load("redrect2_3.png"),pygame.image.load("redrect2_2.png"),pygame.image.load("redrect2_1.png")]


traingbg1=pygame.image.load("trainbg.png")
traingbg2=pygame.image.load("trainbg2.png")
traingbg3=pygame.image.load("trainbg3.png")
traincabin=pygame.image.load("traincabin.png")
transi = [pygame.image.load("transition1.png"), pygame.image.load("transition2.png"), pygame.image.load("transition3.png"), pygame.image.load("transition4.png"), pygame.image.load("transition5.png"), pygame.image.load("transition6.png"), pygame.image.load("transition7.png"), pygame.image.load("transition8.png")]

a_1=0
counter=0
a_2=0
counter_2=0
normal2=True
dupla2=False
waitforit=0
mailincoming=0
man_intro_serial=0
beep_done=False
mail_opening=False
mail_serial=12
helppper=True
timer=0
black_serial=6
dawns=True

redrect2_serial=0
cursor_x, cursor_y= 1155, 560
mail_activeopening=False

start=True
shut_down=False
expanding=True
shrinking=False

pcmail_serial=0
off_timer=20000000
start_timer=0
wentin=True
power_serial=0
mouse_pos=True
pygame.mouse.set_visible(0)
truer=True
sunset=False

train_transi_serial=0
train_transi_status=True
train1_x=0
train2_x=3000
train3_x=6000
t1_lead=True
t2_lead=False
t3_lead=False
train_sound=True
truer2=False
timee=0
csréjn=True






def dawn():
    global black_serial, dawns
    if dawns and pygame.time.get_ticks()>3500:
        if black_serial>0.2:
            black_serial-=0.2
        if black_serial<0.3:
            dawns=False

def normal():
    global counter,a_1, dupla2, normal2, waitforit, colors_serial 
    if normal2 and pygame.time.get_ticks()> 8000:
        if pygame.mixer.music.get_busy()==0 and counter==0:
            pygame.mixer.music.load("keyboard.wav")
            pygame.mixer.music.play()
            counter+=1
        if pygame.mixer.music.get_pos()>3000 and counter==1:
            counter+=1
            pygame.mixer.music.pause()
            waitforit=pygame.time.get_ticks()
        if counter==2 and pygame.time.get_ticks()>(waitforit+2000):
            mixer=pygame.mixer.Sound("mouse.wav")
            mixer.play()
            ido.sleep(0.5)
            counter+=1
            a_1=pygame.time.get_ticks()   
            colors_serial=0    
        if pygame.time.get_ticks()>(waitforit+4000) and counter==3:
            pygame.mixer.music.unpause()
            dupla2=True
            normal2=False

def dupla():
    global counter_2, a_2, dupla2, colors_serial, mailincoming
    if dupla2:
        if pygame.mixer.music.get_busy()==0 and counter_2==0:
            pygame.mixer.music.load("keyboard.wav")
            pygame.mixer.music.play()
            counter_2+=1  
        if pygame.mixer.music.get_pos()>3000 and counter_2==1:
            counter_2+=1
            pygame.mixer.music.pause()           
        if counter_2==2:
            a_2=pygame.time.get_ticks()
            mixer=pygame.mixer.Sound("mouse.wav")
            mixer.play()
            ido.sleep(0.5)
            counter_2=4
            colors_serial=1
        if pygame.time.get_ticks()>(a_2+1500) and counter_2==4:
            mixer=pygame.mixer.Sound("mouse.wav")
            mixer.play()
            ido.sleep(0.5)
            counter_2-=1
            colors_serial=2
        if pygame.time.get_ticks()>(a_2+4000) and counter_2==3:
            pygame.mixer.music.unpause()
            ido.sleep(0.5)
            colors_serial=3
        if pygame.mixer.music.get_pos()>10000 and counter_2==3 :
            dupla2=False
            mailincoming=pygame.time.get_ticks()
            pygame.mixer.music.stop()
            
def mail_on_the_way():
    global beep_done, mail_opening, man_intro_serial, colors_serial
    if pygame.time.get_ticks()>(mailincoming+1000) and not dupla2 and counter_2==3 and not beep_done:
        mixer=pygame.mixer.Sound("gmail.wav")
        mixer.play()
        ido.sleep(1)
        man_intro_serial=1
        intro_display()
        ido.sleep(1.5)
        mixer=pygame.mixer.Sound("mouse.wav")
        mixer.play()
        ido.sleep(0.5)
        beep_done=True
        mail_opening=True     

def cursor_shift():
    global cursor_y, cursor_x, mail_activeopening, mail_serial, helppper, timer
    if cursor_x>=258:
        cursor_x-=26
        cursor_y-=8
    if cursor_x==245 and helppper:
        mixer=pygame.mixer.Sound("mouse.wav")
        mixer.play()
        helppper=not helppper
        mail_activeopening=True
        timer=pygame.time.get_ticks()
    if mail_activeopening and mail_serial>0 and pygame.time.get_ticks()>(timer+1000):
        mail_serial-=1

def watching_desktop():
    global pcmail_serial, cursor_x, cursor_y, wentin, mouse_pos, off_timer
    if mail_opening:
        if pcmail_serial==0:
            cursor_shift()       
        if mail_serial==0:
            if wentin:
                pcmail_serial=1      
                off_timer=pygame.time.get_ticks()
                wentin=False
            if pygame.time.get_ticks()>(off_timer+10000):
                redrect_flash()
                if mouse_pos:
                    pygame.mouse.set_pos((1000,300))
                    mouse_pos=False
                cursor_x,cursor_y=pygame.mouse.get_pos()[0]-24, pygame.mouse.get_pos()[1]-25

def redrect_flash():
    global redrect_serial, start, shut_down, shrinking, expanding, redrect2_serial, pcmail_serial, truer, start_timer, black_serial, sunset
    if start:
        if expanding:
            if redrect_serial<3:
                redrect_serial+=0.075
            else:
                expanding=False
                shrinking=True
        if shrinking:
            if redrect_serial>0:
                redrect_serial-=0.075
            else:
                expanding=True
                shrinking=False

        if 31<pygame.mouse.get_pos()[0]<136 and 709<pygame.mouse.get_pos()[1]<736:
            if pygame.mouse.get_pressed()[0] == 1:
                mixer=pygame.mixer.Sound("mouse.wav")
                mixer.play()
                start=False
                shut_down=True
                expanding=True
                shrinking=False
                pcmail_serial=2
    if shut_down:
        if expanding:
            if redrect2_serial<3:
                redrect2_serial+=0.075
            else:
                expanding=False
                shrinking=True
        if shrinking:
            if redrect2_serial>0:
                redrect2_serial-=0.075
            else:
                expanding=True
                shrinking=False

        if 109<pygame.mouse.get_pos()[0]<284 and 666<pygame.mouse.get_pos()[1]<700:
            if pygame.mouse.get_pressed()[0] == 1:
                mixer=pygame.mixer.Sound("mouse.wav")
                mixer.play()
                black_serial=0
                shut_down=False
                sunset=True

def desktop_sunset():
    global black_serial, sunset, truer,truer2
    if sunset:
        if black_serial<=5.8:
            black_serial+=0.2
        if black_serial>5.8:
            sunset=False
            truer=False
            truer2=True
            screen.fill((0,0,0))

def intro_display():
    if not mail_opening:
        screen.fill((0,0,0))
        screen.blit(man_intro[man_intro_serial],(330,10))
        if dawns:
            screen.blit(black_forsencd[round(black_serial)],(0,0))   
        if pygame.time.get_ticks()> 6000:
            screen.blit(colors_forsencd[colors_serial],(0,0)) 
    if mail_opening:
        screen.blit(pcmail[pcmail_serial],(0,0))
        if mail_activeopening and pygame.time.get_ticks()>(timer+1000) and pcmail_serial==0:
                screen.blit(mail_face[mail_serial],(0,0))
        screen.blit(cursor,(cursor_x, cursor_y))
        if pygame.time.get_ticks()>(off_timer+10000) and not sunset:
            pygame.draw.rect(screen,(0,0,0),((0,744,1400, 28)))
            pygame.draw.rect(screen,(0,0,0),((0,0,26, 800)))
            pygame.draw.rect(screen,(0,0,0),((0,0,1400, 26)))
            pygame.draw.rect(screen,(0,0,0),((1341,0,25, 1500)))
            if start:
                screen.blit(redrect[round(redrect_serial)],(0,0))
            if shut_down:
                screen.blit(redrect2[round(redrect2_serial)],(0,0))
        screen.blit(samsung,(0,0))
        if sunset:
            screen.blit(black_forsencd[round(black_serial)],(0,0))
    if not sunset and not truer and black_serial>5.8:
            screen.fill((0,0,0))
    pygame.display.update()
    if not sunset and not truer and black_serial>5.8:
            ido.sleep(5)    

def update22():
    dawn()
    normal()
    dupla()
    mail_on_the_way()
    redrect_flash()
    watching_desktop()
    desktop_sunset()
    intro_display()

def train_transi():
    global train_transi_serial, train_transi_status
    if train_transi_serial<7:
        train_transi_serial+=0.7
    else:
        train_transi_status=False

def moving_train():
    global train1_x,train2_x,train3_x, t1_lead,t2_lead,t3_lead, train_sound, sunset,black_serial,truer2, timee,csréjn
    if train_sound:
        pygame.mixer.music.load("train.wav")
        timee=pygame.time.get_ticks()
        pygame.mixer.music.play()
        train_sound=False
    train1_x-=15
    train2_x-=15
    train3_x-=15

    if train1_x<-3000:
        train1_x=6000
    if train2_x<-3000:
        train2_x=6000
    if train3_x<-3000:
        train3_x=6000

    if pygame.time.get_ticks()>(timee+22000) and csréjn:
        sunset=True
        csréjn=False
        black_serial=0
        
def train_sunset():
    global black_serial, sunset, truer2
    if sunset:
        if black_serial<=5.8:
            black_serial+=0.2
        if black_serial>5.8:
            sunset=False
            truer2=False
            pygame.mixer.music.stop()
            train()

def train():
    global train_transi_status, train_transi_serial
    screen.blit(traingbg1,(train1_x,0))
    screen.blit(traingbg2,(train2_x,0))
    screen.blit(traingbg3,(train3_x,0))
    screen.blit(traincabin,(0,0))
    if train_transi_status:
        screen.blit(transi[round(train_transi_serial)],(0,0))
    if sunset:
        screen.blit(black_forsencd[round(black_serial)],(0,0))
    if black_serial>5.8 and not sunset and not truer2:
        screen.fill((0,0,0))
    pygame.display.update()

def update33():
    train_transi()
    moving_train()
    train_sunset()
    train()


while True:
    for event in pygame.event.get(): 
        if event.type==pygame.QUIT:
            pygame.quit()
            sys.exit()

    if truer:   
        update22()

    if truer2:
        update33()
        


    clock.tick(60)

