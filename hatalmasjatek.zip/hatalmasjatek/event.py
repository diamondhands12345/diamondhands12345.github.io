import pygame
import sys

pygame.init()

screen= pygame.display.set_mode((300,300))

szia= pygame.USEREVENT +1
my_event = pygame.event.Event(szia)

lista=[["a","b","c"],["d","e","f"],1]



x=False
while True:
    for event in pygame.event.get(): 
        if event.type==pygame.QUIT:
            pygame.quit()
            sys.exit()

    #pygame.event.post(my_event)

    for event in pygame.event.get():
        if event.type == szia:
            print("adfasfafsaf")






    
    pygame.display.update()