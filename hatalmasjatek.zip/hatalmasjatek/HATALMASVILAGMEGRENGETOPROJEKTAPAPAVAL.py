
import pygame
import sys
import time as ido
from datetime import datetime


pygame.init()
clock= pygame.time.Clock()
screen = pygame.display.set_mode(((1366),(768)))
pygame.display.set_caption("The Clue")
actors=True
variablesvalues=True


if variablesvalues:
    x=946
    y=201
    kulx,kuly=0,0
    magniface=0
    ftrx,ftry,ftlx,ftly=1366,0,-1366,0
    font = pygame.font.SysFont(None, 24)
    RED = (255, 0, 0)
    helperx,helpery=1366,0
    a = 0
    t2w = 1366
    t2h = 768
    loadingscreen=True
    streetone=False
    tx,ty=0,0
    lyukas=False
    defek=True
    noting=False
    settings_serial=0
    arrow_serial=0
    insettings_serial=0
    bentvan=False

    user_text1, user_text2, user_text3, user_text4, user_text5, user_text6, user_text7, user_text8 ='','','','','','','',''
    color_active= pygame.Color(223, 48, 48)
    color_passive= pygame.Color('gray15')
    color1, color2, color3, color4, color5, color6,color7, color8, = color_passive,color_passive,color_passive,color_passive,color_passive,color_passive,color_passive,color_passive
    active1,active2,active3,active4,active5,active6,active7,active8 = False, False, False, False, False, False, False, False

    settingsactive=False
    insettings_active=False
    volumesettings, skinsettings, infosettings, in_wrench=False, False, False, False

    adjuster_x= 543
    adjuster_y= 406
    adjuster_x_serial=0
    difference_x, difference_y=0,0
    pullingmouse=False

    transix = 0

    character_x, character_y= 300,400
    character_serial=0
  
if actors:
    character_face=[pygame.image.load("figure1_14.png"),pygame.image.load("figure1_13.png"),pygame.image.load("figure1_12.png"),pygame.image.load("figure1_11.png")]
    magni=[pygame.image.load("magni2.png"),pygame.image.load("magni2.2.png"),pygame.image.load("magni2.3.png"),pygame.image.load("magni2.4.png"),pygame.image.load("magni2.5.png"),pygame.image.load("magni2.6.png"),pygame.image.load("magni2.7.png"),pygame.image.load("magni2.8.png"),pygame.image.load("magni2.9.png")]
    h1=pygame.image.load("menu.png")
    footright=pygame.image.load("footprintright.png")
    footleft=pygame.image.load("footprintleft.png")
    street1=pygame.image.load("hatter1.png")
    notebook = pygame.image.load("notebook.png")
    settingfade=pygame.image.load("settingshadow.png")
    settingssymbol=[pygame.image.load("settings2.png"),pygame.image.load("settings1.png")]
    arrow=[pygame.image.load("arrow1.png"), pygame.image.load("arrow2.png")]
    insettings_face=[pygame.image.load("insettings1.png"),pygame.image.load("insettings2.png"),pygame.image.load("insettings3.png")]

    base_font= pygame.font.Font(None,32)
    input_rect1= pygame.Rect(347,118,140,32)
    input_rect2= pygame.Rect(418,192,140,32)
    input_rect3= pygame.Rect(357,267,140,32)
    input_rect4= pygame.Rect(251,396,140,32)
    input_rect5= pygame.Rect(825,121,140,32)
    input_rect6= pygame.Rect(898,192,140,32)
    input_rect7= pygame.Rect(841,266,140,32)
    input_rect8= pygame.Rect(730,396,140,32)

    transi = [pygame.image.load("transition1.png"), pygame.image.load("transition2.png"), pygame.image.load("transition3.png"), pygame.image.load("transition4.png"), pygame.image.load("transition5.png"), pygame.image.load("transition6.png"), pygame.image.load("transition7.png"), pygame.image.load("transition8.png")]
    
if defek:
    
    def settings():
        global settingsactive, bentvan, settings_serial, arrow_serial, time, date, clock1, clock2, insettings_serial, volumesettings, skinsettings, infosettings, in_wrench, insettings_active, difference_y, difference_x, adjuster_x, adjuster_y, mouse_y, mouse_x,pullingmouse

        if event.type==pygame.MOUSEBUTTONUP:
                    pullingmouse=False
        if pressed[pygame.K_ESCAPE]:
            if settingsactive==False:
                settingsactive= not settingsactive
        if bentvan and pygame.mouse.get_pressed()[0]==1:
            settingsactive=False
            bentvan=False
        if settingsactive:
            if pygame.mouse.get_pos()[0]<579 or 779<pygame.mouse.get_pos()[0]:
                settings_serial=0
                in_wrench=False
            
            if pygame.mouse.get_pos()[1]<278 or 492<pygame.mouse.get_pos()[1]:
                settings_serial=0
                in_wrench=False

            if 579 < pygame.mouse.get_pos()[0]< 779 and 278 < pygame.mouse.get_pos()[1] < 492 and not insettings_active:
                settings_serial=1
                in_wrench=True
                
            
        if settingsactive:
            if pygame.mouse.get_pos()[0]<40 or 120<pygame.mouse.get_pos()[0] and not insettings_active:
                arrow_serial=0
                bentvan=False
            if pygame.mouse.get_pos()[1]<50 or 110<pygame.mouse.get_pos()[1] and not insettings_active:
                arrow_serial=0
                bentvan=False
            if 40 < pygame.mouse.get_pos()[0]< 110 and 50 < pygame.mouse.get_pos()[1] < 110 and not insettings_active:
                arrow_serial=1
                bentvan=True

        date= datetime.now().date()
        time= datetime.now().time()
        fontclock1 = pygame.font.SysFont("Trebuchet MS", 40)
        fontclock2 = pygame.font.SysFont("Trebuchet MS", 50)
        clock1 = fontclock1.render((str(date.year)+"."+str(date.month)+"."+str(date.day)+"."), True, (255,255, 255))
        clock2 = fontclock2.render((str(time.hour)+":"+str(time.minute)), True,(0,0,0) )

        if in_wrench and pygame.mouse.get_pressed()[0]==1:
            insettings_active=True
            insettings_serial=0
            in_wrench=False

        if pygame.mouse.get_pressed()[0]==1 and insettings_active:
            
            if 208 < pygame.mouse.get_pos()[0]< 509 and 119 < pygame.mouse.get_pos()[1] < 209 and not pullingmouse:
                insettings_serial=0
                infosettings=True
                skinsettings=False
                volumesettings=False
            if 522 < pygame.mouse.get_pos()[0]< 838 and 119 < pygame.mouse.get_pos()[1] < 209 and not pullingmouse:
                insettings_serial=1
                skinsettings=True
                infosettings=False
                volumesettings=False
            if 852 < pygame.mouse.get_pos()[0]< 1155 and 119 < pygame.mouse.get_pos()[1] < 209:
                insettings_serial=2
                volumesettings=True
                infosettings=False
                skinsettings=False
            if True:
                if (pygame.mouse.get_pos()[0]<195 or 1169<pygame.mouse.get_pos()[0]) and not pullingmouse:
                    insettings_active=False
                    volumesettings=False
                    infosettings=False
                    skinsettings=False
                    
                if (pygame.mouse.get_pos()[1]<107 or 659<pygame.mouse.get_pos()[1]) and not pullingmouse:
                    insettings_active=False
                    volumesettings=False
                    infosettings=False
                    skinsettings=False
            
            if volumesettings:
                mouse_x,mouse_y=pygame.mouse.get_pos()
                
                if pygame.mouse.get_pressed()[0] == 1 and adjuster_x<mouse_x<(adjuster_x+25) and 406<mouse_y<487:
                    
                    pullingmouse=True
                if pullingmouse:
                    mouse_x,mouse_y=pygame.mouse.get_pos()
                    if event.type==pygame.MOUSEBUTTONDOWN:
                        difference_x,difference_y=(mouse_x-adjuster_x),(mouse_y-adjuster_y)
                    adjuster_x=(mouse_x-difference_x)
                    if adjuster_x<544:
                        adjuster_x=544
                    if adjuster_x>795:
                        adjuster_x=795
                
    def nagyitomozgatas():
        global x, y, kulx, kuly
        if pygame.mouse.get_pressed()[0] == 1 and x+101 < pygame.mouse.get_pos()[0] < x+155 and y+286 < pygame.mouse.get_pos()[1] < y+517:
            egerx,egery=pygame.mouse.get_pos()
            if event.type==pygame.MOUSEBUTTONDOWN:
                kulx, kuly = (egerx - x), (egery - y)        
            x, y = (egerx - kulx), (egery - kuly)  

    def toltes():
        global x, y, magniface
        mehet=True
        if mehet:
            if 210<y<317 and 490<x<596 and magniface<8:
                magniface+=0.04
            
                
            elif magniface==8:
                mehet=False

                
            elif magniface<8:

                magniface=0

    def transition():
        global magniface, ftrx,ftry, ftlx,ftly, helperx, streetone, loadingscreen, a, loadingscreen, tx,ty, t2w, t2h,  transix

        if magniface>=8 and ftrx>10:
            screen.blit(footright,(ftrx,ftry))
            screen.blit(footleft,(ftlx,ftly))
            helper=pygame.Rect(helperx,helpery,683,768)
            pygame.draw.rect(screen,(0,0,0),helper)
            ftrx-=10
            helperx=ftrx+683
            ftlx+=10
        
        if ftrx<=10 and transix <= 7:
            screen.blit(street1, (0, 0))
            screen.blit(transi[transix], (0, 0))
            transix += 1
            ido.sleep(0.03)
        elif loadingscreen and transix > 7:
            ido.sleep(0.03)
            loadingscreen = False
            streetone = True 
        
    def update():
        global settingsactive, settings_serial
        screen.blit(h1,(0,0))
        screen.blit(magni[round(magniface)],(x,y))
        egerx,egery=pygame.mouse.get_pos()
        img = font.render((str(x)+" "+str(y)+" "+str(egerx)+" "+str(egery)), True, RED)
        screen.blit(img, (20, 200))
        if magniface>=8:
            transition()
        if settingsactive:
            screen.blit(settingfade,(0,0))
            screen.blit(settingssymbol[round(settings_serial)],(566,272))
            screen.blit(arrow[arrow_serial],(15,15))
            screen.blit(clock1, (1150, 690))
            screen.blit(clock2, (620, 650))
            if insettings_active:
                screen.blit(insettings_face[insettings_serial],(200,113))
                if volumesettings:
                    adjuster=pygame.Rect(adjuster_x,adjuster_y,25,81)
                    pygame.draw.rect(screen,(0,0,0),adjuster,0)  
        pygame.display.update()

    def notepad():
        global noting
        pressed=pygame.key.get_pressed()
        if pressed[pygame.K_n] and not noting:
            noting= True
        if pressed[pygame.K_ESCAPE] and (not active1 and not active2 and not active3 and not active4 and not active5 and not active6 and not active7 and not active8) :
            noting=False
            
    def update2():
        global noting, color1, color2, color3, input_rect1, input_rect2, input_rect3, user_text1, user_text2, user_text3, active1, active2, active3, settingsactive
        screen.blit(street1,(0,0))
        screen.blit(character_face[character_serial],(character_x,character_y))
        


        if noting:
            screen.blit(notebook,(183,53))
   
            pygame.draw.rect (screen,color1,input_rect1, 2)
            pygame.draw.rect (screen,color2,input_rect2, 2)
            pygame.draw.rect (screen,color3,input_rect3, 2)
            pygame.draw.rect (screen,color4,input_rect4, 2)
            pygame.draw.rect (screen,color5,input_rect5, 2)
            pygame.draw.rect (screen,color6,input_rect6, 2)
            pygame.draw.rect (screen,color7,input_rect7, 2)
            pygame.draw.rect (screen,color8,input_rect8, 2)


            text_surface1= base_font.render (user_text1, True, (0,0,0))
            screen.blit(text_surface1,(input_rect1.x +5, input_rect1.y +5))
            input_rect1.w =max(100, text_surface1.get_width()+10)

            text_surface2= base_font.render (user_text2, True, (0,0,0))
            screen.blit(text_surface2,(input_rect2.x +5, input_rect2.y +5))
            input_rect2.w =max(100, text_surface2.get_width()+10)

            text_surface3= base_font.render (user_text3, True, (0,0,0))
            screen.blit(text_surface3,(input_rect3.x +5, input_rect3.y +5))
            input_rect3.w =max(100, text_surface3.get_width()+10) 

            text_surface4= base_font.render (user_text4, True, (0,0,0))
            screen.blit(text_surface4,(input_rect4.x +5, input_rect4.y +5))
            input_rect4.w =max(100, text_surface4.get_width()+10)

            text_surface5= base_font.render (user_text5, True, (0,0,0))
            screen.blit(text_surface5,(input_rect5.x +5, input_rect5.y +5))
            input_rect5.w =max(100, text_surface5.get_width()+10)

            text_surface6= base_font.render (user_text6, True, (0,0,0))
            screen.blit(text_surface6,(input_rect6.x +5, input_rect6.y +5))
            input_rect6.w =max(100, text_surface6.get_width()+10)

            text_surface7= base_font.render (user_text7, True, (0,0,0))
            screen.blit(text_surface7,(input_rect7.x +5, input_rect7.y +5))
            input_rect7.w =max(100, text_surface7.get_width()+10)

            text_surface8= base_font.render (user_text8, True, (0,0,0))
            screen.blit(text_surface8,(input_rect8.x +5, input_rect8.y +5))
            input_rect8.w =max(100, text_surface8.get_width()+10)

        

        egerx,egery=pygame.mouse.get_pos()
        img = font.render((str(x)+" "+str(y)+" "+str(egerx)+" "+str(egery)), True, RED)
        screen.blit(img, (20, 100))
        if settingsactive:
            screen.blit(settingfade,(0,0))
            screen.blit(settingssymbol[round(settings_serial)],(566,272))
            screen.blit(arrow[arrow_serial],(15,15))
            screen.blit(clock1, (1150, 690))
            screen.blit(clock2, (620, 650))
            if insettings_active:
                    screen.blit(insettings_face[insettings_serial],(200,113))
                    if volumesettings:
                        adjuster=pygame.Rect(adjuster_x,adjuster_y,25,81)
                        pygame.draw.rect(screen,(0,0,0),adjuster,0)
        pygame.display.update()
    
    program=True

if program:

    while True:
        pressed=pygame.key.get_pressed()
        for event in pygame.event.get(): 
            if event.type==pygame.QUIT:
                pygame.quit()
                sys.exit()
            if noting:
                if True:
                    if event.type == pygame.MOUSEBUTTONDOWN:
                        if input_rect1.collidepoint(event.pos):
                            active1=True
                            active2=False
                            active3=False
                            active4=False
                            active5=False
                            active6=False
                            active7=False
                            active8=False
                            color1=color_active
                            color2=color_passive
                            color3=color_passive
                            color4=color_passive
                            color5=color_passive
                            color6=color_passive
                            color7=color_passive
                            color8=color_passive
                        elif input_rect2.collidepoint(event.pos):
                            active2=True
                            active1=False
                            active3=False
                            active4=False
                            active5=False
                            active6=False
                            active7=False
                            active8=False
                            color2=color_active
                            color1=color_passive
                            color3=color_passive
                            color4=color_passive
                            color5=color_passive
                            color6=color_passive
                            color7=color_passive
                            color8=color_passive
                        elif input_rect3.collidepoint(event.pos):
                            active3=True
                            active1=False
                            active2=False
                            active4=False
                            active5=False
                            active6=False
                            active7=False
                            active8=False
                            color3=color_active
                            color1=color_passive
                            color2=color_passive
                            color4=color_passive
                            color5=color_passive
                            color6=color_passive
                            color7=color_passive
                            color8=color_passive
                        elif input_rect4.collidepoint(event.pos):
                            active1=False
                            active2=False
                            active3=False
                            active4=True
                            active5=False
                            active6=False
                            active7=False
                            active8=False
                            color4=color_active
                            color1=color_passive
                            color2=color_passive
                            color3=color_passive
                            color5=color_passive
                            color6=color_passive
                            color7=color_passive
                            color8=color_passive
                        elif input_rect5.collidepoint(event.pos):
                            active5=True
                            active1=False
                            active2=False
                            active3=False
                            active4=False
                            active6=False
                            active7=False
                            active8=False
                            color5=color_active
                            color1=color_passive
                            color2=color_passive
                            color3=color_passive
                            color4=color_passive
                            color6=color_passive
                            color7=color_passive
                            color8=color_passive
                        elif input_rect6.collidepoint(event.pos):
                            active6=True
                            active1=False
                            active2=False
                            active3=False
                            active4=False
                            active5=False
                            active7=False
                            active8=False
                            color6=color_active
                            color1=color_passive
                            color2=color_passive
                            color3=color_passive
                            color4=color_passive
                            color5=color_passive
                            color7=color_passive
                            color8=color_passive
                        elif input_rect7.collidepoint(event.pos):
                            active7=True
                            active1=False
                            active2=False
                            active3=False
                            active4=False
                            active5=False
                            active6=False
                            active8=False
                            color7=color_active
                            color1=color_passive
                            color2=color_passive
                            color3=color_passive
                            color4=color_passive
                            color5=color_passive
                            color6=color_passive
                            color8=color_passive
                        elif input_rect8.collidepoint(event.pos):
                            active8=True
                            active1=False
                            active2=False
                            active3=False
                            active4=False
                            active5=False
                            active6=False
                            active7=False
                            color8=color_active
                            color1=color_passive
                            color2=color_passive
                            color3=color_passive
                            color4=color_passive
                            color5=color_passive
                            color6=color_passive
                            color7=color_passive
                        else:
                            active1=False
                            active2=False
                            active3=False
                            active4=False
                            active5=False
                            active6=False
                            active7=False
                            active8=False
                            color1=color_passive
                            color2=color_passive
                            color3=color_passive
                            color4=color_passive
                            color5=color_passive
                            color6=color_passive
                            color7=color_passive
                            color8=color_passive

                if active1 or active2 or active3 or active4 or active5 or active6 or active7 or active8:
                    if event.type == pygame.KEYDOWN:
                        if active1 == True:
                            if event.key== pygame.K_BACKSPACE:
                                if event.key!= pygame.K_ESCAPE:
                                    user_text1=user_text1[:-1]
                            elif len(user_text1)<20:
                                if event.key!= pygame.K_ESCAPE:
                                    user_text1 += event.unicode

                        elif active2 == True:
                            if event.key== pygame.K_BACKSPACE:
                                    user_text2=user_text2[:-1]
                            elif len(user_text2)<15:
                                if event.key!= pygame.K_ESCAPE:
                                    user_text2 += event.unicode

                        elif active3 == True:
                            if event.key== pygame.K_BACKSPACE:
                                user_text3=user_text3[:-1]
                            elif len(user_text3)<19:
                                if event.key!= pygame.K_ESCAPE:
                                    user_text3 += event.unicode 

                        elif active4 == True:
                            if event.key== pygame.K_BACKSPACE:
                                    user_text4=user_text4[:-1]
                            elif len(user_text4)<24:
                                if event.key!= pygame.K_ESCAPE:
                                    user_text4 += event.unicode

                        elif active5 == True:
                            if event.key== pygame.K_BACKSPACE:
                                user_text5=user_text5[:-1]
                            elif len(user_text5)<20:
                                if event.key!= pygame.K_ESCAPE:
                                    user_text5 += event.unicode

                        elif active6 == True:
                            if event.key== pygame.K_BACKSPACE:
                                    user_text6=user_text6[:-1]
                            elif len(user_text6)<15:
                                if event.key!= pygame.K_ESCAPE:
                                    user_text6 += event.unicode

                        elif active7 == True:
                            if event.key== pygame.K_BACKSPACE:
                                user_text7=user_text7[:-1]
                            elif len(user_text7)<19:
                                if event.key!= pygame.K_ESCAPE:
                                    user_text7 += event.unicode

                        elif active8 == True:
                            if event.key== pygame.K_BACKSPACE:
                                    user_text8=user_text8[:-1]
                            elif len(user_text8)<24:
                                if event.key!= pygame.K_ESCAPE:
                                    user_text8 += event.unicode   

             

        if loadingscreen:
            if not settingsactive:
                nagyitomozgatas()
                toltes()
            settings()
            update()


            
        if streetone:
            if not settingsactive:
                notepad()
            settings()
            update2()

        
        if pressed[pygame.K_RIGHT]:
            character_x+=10
            if character_serial<2:
                character_serial+=1
            else:
                character_serial=0
        
        if pressed[pygame.K_LEFT]:
            character_x-=10
            if character_serial<2:
                character_serial+=1
            else:
                character_serial=0
        if pressed[pygame.K_UP]:
            character_y-=10

        if pressed[pygame.K_DOWN]:
            character_y+=10
        clock.tick(60)


            
            ##############################
            ##           <<>>           ##
            ##           <<>>           ##
            ##           <<>>           ##
            ##    <<<<<<<<<>>>>>>>>>    ##
            ##    <<<<<<<<<>>>>>>>>>    ##
            ##           <<>>           ##
            ##           <<>>           ##
            ##           <<>>           ##
            ##           <<>>           ##
            ##           <<>>           ##
            ##           <<>>           ##
            ##############################



            ##############################
            ##       <<<<<<>>>>>>       ##
            ##     <<<          >>>     ##
            ##    <<              >>    ##
            ##     <              >>    ##
            ##                  >>>     ##
            ##                >>>       ##
            ##             >>>>         ##
            ##            <>            ##
            ##                          ##
            ##           <<>>           ##
            ##           <<>>           ##
            ##############################


